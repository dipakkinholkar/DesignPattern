package singleton.manimum;

public class Printer {

	private static Printer instance;
	
	private Printer()
	{
	//private constructor
		System.out.print("0 par-constructor");
		
	}
	
	public static Printer getInstance()
	{
		if(instance==null)
		{
		instance=new Printer();
		}
		
		return instance;
		
	}
	
	public void msg(String msg)
	{
		System.out.print("message"+msg);
	}
	
}
