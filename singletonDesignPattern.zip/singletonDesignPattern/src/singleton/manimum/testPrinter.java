package singleton.manimum;

public class testPrinter {

	public static void main(String[] args) {
	
		
		// Printer pw=new Printer(); invalid code
		
		Printer pw=Printer.getInstance();
		
		pw.msg("hello");
		
		Printer pw1=Printer.getInstance(); 
		

		pw1.msg("hello");
		
		System.out.println(pw==pw1);
		
		System.out.println(pw);
		
		System.out.println(pw1);
		
	}

}
