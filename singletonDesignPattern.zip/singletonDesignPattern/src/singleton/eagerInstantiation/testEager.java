package singleton.eagerInstantiation;

public class testEager {

	public static void main(String[] args) {
	
		
		// Printer pw=new Printer(); invalid
		
		
		Printer pw=Printer.getInstance();
		
		Printer pw1=Printer.getInstance();
		
		System.out.println("pw :::"+pw);
		System.out.println("pw :::"+pw1);
		
		pw.msg("hello");
		
		
	}

}
