package singleton.eagerInstantiation;

public class Printer {
	
	private static Printer pw=new Printer();
	
	private Printer()
	{
		System.out.println("0 par-construtor ");
		
		System.out.println(pw);
		
	}
	
	public static Printer getInstance()
	{
		return pw;
	}
	
	
	
	public void msg(String msg)
	{
		System.out.println(msg);
	}
	
	
	
	

}
